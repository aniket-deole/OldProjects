Project 1 for CSE 589: Modern Networking Concepts.
A small client server application that can share files.

Modules:
IP Handler - This manages IP Addresses and hostnames. It also interconverts between them. (1)
Command Line Handler (2)
Server Main Loop (3)
Client Main Loop (4)
Display CREATOR
Display HELP
Display MYIP
Display MYPORT
Chat / Message Manager.
File Manager. (5)
Optimizer: Data Rates Vs Packet Size.
