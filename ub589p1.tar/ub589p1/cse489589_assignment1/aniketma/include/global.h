#ifndef GLOBAL_H_
#define GLOBAL_H_

#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>      
#include <netdb.h>
#include <ifaddrs.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <libgen.h>
#include <math.h>


#define MAXLINE 80
#define TEXT_DATA_LIMIT 1024

#define MAX_PEERS 4
#define MAX_CONNECTED_PEERS 3
#define FILE_PART_SIZE 2048

#include "defs.h"

#define HOSTNAME_LEN 128
#define MAX_PARALLEL_DOWNLOAD 3

#define SERVER_IDENTIFIER_CMD "s"
#define CLIENT_IDENTIFIER_CMD "c"

#define LOOPBACK "lo"
#define LISTEN_BACKLOG 1024
#define STDIN 0
#define STDOUT 1

#define SERVER 1
#define CLIENT 2
/**
 * PACKET IDENTIFIERS
 */
#define IM_A_CLIENT 1
#define IM_A_PEER 2
#define IM_A_PEERLIST 3
#define IM_A_FILE 4
#define IM_A_MESSAGE 5
#define IM_A_FILEPART 6
#define IM_A_FILE_REQUEST 7
#define IM_A_STAT_REQUEST 8
#define IM_A_STAT_ARRAY 9
/** 
 * PACKET IDENTIFIERS OVER
 */
/*
 * MISC
 */
#define GOOGLE_DNS "8.8.8.8"
#define GOOGLE_DNS_PORT 53

#define CLIENT_LIST 1
#define PEER_LIST 2

void run_server (int);
int run_client (int);
struct server svr;
struct client cli;
fd_set read_fds;
fd_set master;
int fdmax;
int machine_type;
int listenfd;
#endif
