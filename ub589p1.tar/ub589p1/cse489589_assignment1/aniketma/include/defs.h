#ifndef __PROJECT_ONE__
#define __PROJECT_ONE__

#include "global.h"

struct peer_list_node;

/**
 * NOTE
 * Any data that is passed over sockets must not have pointers.
 * If at all it has any, they must be set to NULL
 * before transmitting.
 */

/*
 * Speed = Total bytes_transferred / Total time.
 * I do not take the mean of transfers. but use the 
 * above formula to calculate statistics.
 */
struct sub_stats {
	char target_name[1024];
	int bytes_transferred; /* bytes recieved */
	int bs; /* bytes sent */
	long int milliseconds_transferred; /* time spent in recieving */
	long int ms; /* time spent in sending */
	int uploads;
	int downloads;
};

struct master_stats {
	int magic;
	char self_name[1024];
	struct sub_stats s_stats[MAX_PEERS];
};

/**
 * Client initializes this when it starts.
 * This is then sent over to the server for 
 * registration.
 * The pointer peers is filled with NULL before sending.
 */
struct client {
	int magic;
	struct sockaddr_in address;
	struct addrinfo res;
	char name[1024];
	char ip_address[1024];
	char service[14];
	unsigned int port;
	int fd;
	int open_file_descriptor;
	struct peer_list_node* peers;
	struct master_stats statistics;
	struct timeval file_transfer_start;
};

/**
 * struct peer_list_node is intialized and
 * maintained by the clients.
 * It contains a list of all peers / other clients.
 * Passed over sockets.
 */
struct peer_list_node {
	int magic;
	int peers;
	struct client clients[MAX_PEERS];
};

/**
 * The server intializes tihs when it starts.
 * It is passed to the client once it registers itself with 
 * the server.
 * The pointer 'clients' to client_list_node is
 * made to point to NULL before sending.
 */
struct server {
	struct sockaddr_in address;
	struct addrinfo res;
	char name[1024];
	char ip_address[1024];
	char service[14];
	unsigned int port;
	int fd;
	unsigned int clients_connected;
	struct client clients[MAX_PEERS];
};

/**
 * struct file describes a file. :P
 * source / target members are not used as of now.
 */
struct file {
	int magic;
	char name[1024];
	size_t size;
};

/**
 * File Part along with the sequence number and the file it represents.
 */
struct part {
	int magic;
	struct file parent;
	int last_part_flag;
	/*
	 * This will be useful to read the last packet which has
	 * file size < FILE_PART_SIZE.
	 */
	size_t actual_size_of_payload;
	char data[FILE_PART_SIZE];
};

/**
 * Text Message sent on the console.
 *
 */
struct message {
	int magic;
	char text[TEXT_DATA_LIMIT];
};


/**
 * FUNCTION DEFS
 */
void add_client_to_list (struct client*);
ssize_t readm (int, int*, char*);
void handle_new_connection (int, int*, fd_set*);
void handle_command_line (int, char*);
int select_loop (int listenfd, int readable_fds);
int connect_to_server (int, char*, int);
void send_peer_list ();

#endif
