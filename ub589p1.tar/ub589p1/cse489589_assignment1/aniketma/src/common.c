#include "global.h"
#include "defs.h"

void display_stats_on_server () {

	int i = 0, j =0;
	printf ("%-30s%-30s%-15s%-15s%-17s%-15s\n",
			"Hostname1", "Hostname2", "Total Uploads", "Avg Tx Rate", "Total downloads","Avg Rx Rate");
	for (j = 0; j < MAX_PEERS; j++) {
		for (i = 0; i < MAX_PEERS; i++) {
			if (svr.clients[j].statistics.s_stats[i].uploads == 0 &&
				svr.clients[j].statistics.s_stats[i].downloads == 0) {
					continue;
				} else { 
			printf ("%-30s%-30s%-15d%-15f%-17d%-15f\n", 
					svr.clients[j].name,
					svr.clients[j].statistics.s_stats[i].target_name,
					svr.clients[j].statistics.s_stats[i].uploads, 
					(svr.clients[j].statistics.s_stats[i].uploads > 0 ? 
					 ((svr.clients[j].statistics.s_stats[i].bs) / (float) svr.clients[j].statistics.
						s_stats[i].ms) : 0),
					svr.clients[j].statistics.s_stats[i].downloads,
					(svr.clients[j].statistics.s_stats[i].downloads > 0 ?
					 ((svr.clients[j].statistics.s_stats[i].bytes_transferred)/ (float) svr.clients[j].statistics.s_stats[i].milliseconds_transferred) : 0));
		}
		}
	}
	fflush (stdout);
}

void send_stat_structure_to_server (int fd) {
	struct master_stats* ms = malloc (sizeof (struct master_stats));
	bzero (ms, sizeof (struct master_stats));
	memcpy (ms, &(cli.statistics), sizeof (struct master_stats));
	ms->magic = IM_A_STAT_ARRAY;
	int w = writen (svr.fd, ms, sizeof (struct master_stats));
	if (w < 0)
		perror ("Stat Structure Send Error");
	free (ms);
}

/*
 * This function does not actual print stats.
 * But it sends the request for one.
 */
void print_server_statistics () {
	int i; 
	for (i = 0; i < MAX_PEERS; i++) {
		if (svr.clients[i].fd != 0) {
			int flag = IM_A_STAT_REQUEST;
			writen (svr.clients[i].fd, &flag, sizeof (int));
		}
	}

	for (i = 0; i < MAX_PEERS; i++) {
		bzero (&(svr.clients[i].statistics),
				sizeof (struct master_stats));
	}
}

void print_statistics () {
	if (machine_type == SERVER) {
		print_server_statistics ();
		return;
	}
	int i = 0;
	printf ("%-30s%-15s%-15s%-17s%-15s\n",
			"Hostname", "Total Uploads", "Avg Tx Rate", "Total downloads","Avg Rx Rate");
	for (i = 0; i < MAX_PEERS; i++) {
		//		if (strcmp (cli.statistics.s_stats[i].target_name, cli.name))
		if (cli.statistics.s_stats[i].uploads == 0
		 && cli.statistics.s_stats[i].downloads == 0) {
			continue;
		 } else
		printf ("%-30s%-15d%-15f%-17d%-15f\n", 
				cli.statistics.s_stats[i].target_name, 
				cli.statistics.s_stats[i].uploads, 
				(cli.statistics.s_stats[i].uploads > 0 ? 
				 (cli.statistics.s_stats[i].bs / (float) cli.statistics.
					s_stats[i].ms) : 0),
				cli.statistics.s_stats[i].downloads,
				(cli.statistics.s_stats[i].downloads > 0 ?
				 (cli.statistics.s_stats[i].bytes_transferred / (float) cli.statistics.s_stats[i].milliseconds_transferred) : 0));
	}
	fflush (stdout);
}


struct client* get_client_from_fd (int f) {
	if (machine_type == CLIENT) {
		int i;
		for (i = 0; i < MAX_PEERS; i++) {
			if (f == cli.peers->clients[i].fd) {
				struct client* cc = &(cli.peers->clients[i]);
				return cc;
			}
		}
	} else if (machine_type == SERVER) {
		return;
	}
}

void exit_process () {
	int i;
	if (machine_type == SERVER) {
		for (i = 0; i < MAX_PEERS; i++) {
			if (svr.clients[i].fd != 0) {
				if (shutdown (svr.clients[i].fd, SHUT_RDWR) < 0) {
				}
				close (svr.clients[i].fd);
				svr.clients[i].fd = 0;
			}
		}
		close (listenfd);
		exit (0);
	}

	if (machine_type == CLIENT) {
		for (i = 0; i < MAX_PEERS; i++){
			if (cli.peers != NULL) {
				if (cli.peers->clients [i].fd != 0) {
					if (shutdown (cli.peers->clients[i].fd, 0) < 0) {
					}
					close (cli.peers->clients[i].fd);
					cli.peers->clients[i].fd = 0;
				}
			}
		}
		if (svr.fd != 0) {
			if (shutdown (svr.fd, SHUT_RDWR) < 0) {
			}
			close (svr.fd);
			svr.fd = 0;
		}
		close (listenfd);
		exit (0);
	}
}

void terminate_connection (char* data) {
	char command[strlen ("TERMINATE")];
	int peer_id_to_disconnect = 0;
	sscanf (data, "%s %d", command, &peer_id_to_disconnect);
	int r = 0;
	printf("Shutting Down %d\n", peer_id_to_disconnect);
	if ((r = shutdown (peer_id_to_disconnect, SHUT_RDWR)) < 0) {
		perror ("Terminate Error");
		return;
	}
	int i;
	for (i = 0; i < MAX_PEERS; i++) {
		if (machine_type == CLIENT) {
			if (cli.peers->clients[i].fd == peer_id_to_disconnect) {
				FD_CLR (cli.peers->clients[i].fd, &master);
				close (cli.peers->clients[i].fd);
				cli.peers->clients[i].fd = 0;
				return;
			}
		} else if (machine_type == SERVER) {
			if (svr.clients[i].fd == peer_id_to_disconnect) {
				FD_CLR (svr.clients[i].fd, &master);
				close (svr.clients[i].fd);
				bzero (&(svr.clients[i]), sizeof (struct client));
				return;
			}
		}
	}
	return;
}

/**
 * DOWNLOAD FILES
 * CLIENT METHOD
 */

void download_files (char* data) {
	char command[strlen ("DOWNLOAD")];
	int peer_index;
	int i = 0, j; int p_counter = 1;
	char file_path[1024];
	int file_name_i;
	sscanf (data, "%s %d %s", command, &peer_index, file_path);
	char* tokens;
	char* final_tokens[7];
	int tokens_q = 0;
	for (i = 0; i < 7; i++)
		final_tokens[i] = malloc (sizeof (1024));
	tokens = strtok (data, " ");
	i = 0;
	while (tokens != NULL) {
		tokens_q++;
		final_tokens[i] = tokens;
		tokens = strtok (NULL, " ");
		i++;
	}
	if (tokens_q == 3 ||
			tokens_q == 5 || tokens_q == 7) {
	}
	peer_index = peer_index - 1;
	int p_connected = cli.peers->peers;
	int loop = 0;
	if (tokens_q == 3)
		loop = 1;
	if (tokens_q == 5)
		loop = 2;
	if (tokens_q == 7)
		loop = 3;
	for (j = 0; j < loop; j++) {
		for (i = 0; i < MAX_PEERS; i++) {
			if (cli.peers->clients[i].fd == 0) {
				continue;
			} else {
				int target = 0;
				int file = 0;
				if (j == 0) {
					target = 1;
					file_name_i = 2;
				} else if (j == 1) {
					target = 3;
					file_name_i = 4;
				} else if (j == 3) {
					target = 5;
					file_name_i = 6;
				}
				if (cli.peers->clients[i].fd == atoi (final_tokens[target])) {
					/**
					 * We need to download the file from this
					 * client object.
					 */
					printf ("Sending file request to %d.\n", i);
					struct file* f = (struct file*) malloc (sizeof (struct file));
					if (j == (loop - 1))
						strncpy (f->name, final_tokens[file_name_i], 
								strlen (final_tokens [file_name_i]) - 1);
					else
						strcpy (f->name, final_tokens[file_name_i]);
					f->magic = IM_A_FILE_REQUEST;
					int w = writen (cli.peers->clients[i].fd,
							f, sizeof (struct file));
					if (w <= 0) {
						perror ("Cannot Write File Request");
						break;
					}
					break;
				} else {
					p_counter++;
				}
			}
		}
	}
}

/**
 * CLIENT METHOD
 */
void connect_to_peer (char* data) {
	int ip1 = 0, ip2 = 0, ip3 = 0, ip4 = 0;
	int port;
	char command[strlen("CONNECT")];
	char ip[1024];
	sscanf (data, "%s %s %d", command, ip, &port);
	struct peer_list_node* pln = cli.peers;

	if (!strcmp (ip, cli.ip_address) && port == cli.port) {
		/**
		 * Cannot Self Connect
		 */
		printf ("Cannot self Connect.\n");
		return;
	} else if (!strcmp (ip, cli.name) && port == cli.port) {
		printf ("Cannot self Connect.\n");
	}

	int i;
	int peers_connected;
	for (i = 0; i <MAX_PEERS;i++) {
		if (pln->clients[i].fd != 0)
			peers_connected++;
	}

	if (peers_connected == MAX_CONNECTED_PEERS) {
		printf ("Maximum number of client connections reached. Cannot connect.\n");
		fflush (stdout);
		return;
	}

	for (i = 0; i < MAX_PEERS; i++) {
		if ((pln->clients[i].port == port
					&& !strcmp (pln->clients[i].ip_address, ip)) ||
				(pln->clients[i].port == port 
				 && !strcmp (pln->clients[i].name, ip))) {

			if (!strcmp (pln->clients[i].name, ip)) {
				strcpy (ip, pln->clients[i].ip_address);
			}

			if (pln->clients[i].fd != 0) {
				printf ("Client already connected.\n");
				fflush (stdout);
				return;
			}
			struct sockaddr_in servaddr;
			bzero (&servaddr, sizeof (struct sockaddr_in));

			int sockfd, n;
			sockfd = socket (AF_INET, SOCK_STREAM, 0);
			servaddr.sin_family = AF_INET;
			servaddr.sin_port = htons (port);

			inet_pton (AF_INET, ip, &servaddr.sin_addr);
			if (connect (sockfd, (struct sockaddr*) &servaddr,
						sizeof (servaddr)) < 0) {
				perror ("Cannot connect to peer\n");
				return;
			} else {
				printf ("Connected to another client.\n");
				fflush (stdout);
			}
			if (sockfd >= fdmax)
				fdmax = sockfd;

			FD_SET (sockfd, &master);
			FD_SET (sockfd, &read_fds);


			/**
			 * Sent client structure to that process.
			 */
			struct client* c = (struct client*) malloc (sizeof (struct client));
			memcpy (c, &cli, sizeof (struct client));
			c->magic = IM_A_PEER;
			c->fd = 0;
			pln->clients[i].fd = sockfd;
			int w = writen (pln->clients[i].fd, c, sizeof (struct client));
			if (w <= 0)
				perror ("Cannot send client struct to peer");

			break;
		}
	}
}

/**
 * CLIENT METHOD
 */
void print_peer_list (int flag) {
	int i;
	if (cli.peers == NULL) {
		return;
	}
	/*	if (svr.port != 0) {
			printf ("%-5d%-35s%-20s%-8d\n", 1,
			svr.name, svr.ip_address, svr.port);
			}*/
	printf ("Update Server-IP List\n");
	int k = 1;
	for (i = 0; i < MAX_PEERS; i++) {
		if (cli.peers->clients[i].port == cli.port &&
				!strcmp (cli.peers->clients[i].name, cli.name) && 0) {
			/**
			 * This peer is the same as this client. Added 0 above
			 * self print.
			 */
		} else {
			if (cli.peers->clients[i].port != 0) {
				if (flag == CLIENT_LIST) {
					printf ("%-5d%-35s%-20s%-8d%-8d\n", k, cli.peers->clients[i].name,
							cli.peers->clients[i].ip_address,
							cli.peers->clients[i].port, i);
					k++;

				}else if (flag == PEER_LIST) {
					if (cli.peers->clients[i].fd != 0) {
						printf ("%-5d%-35s%-20s%-8d%-8d\n", cli.peers->clients[i].fd, 
								cli.peers->clients[i].name,
								cli.peers->clients[i].ip_address,
								cli.peers->clients[i].port, i);
						k++;
					}
				}
			}
		}
	}
}

/**
 * SERVER METHOD
 */
void print_client_list () {
	int i;
	for (i = 0; i < MAX_PEERS; i++) {
		if (svr.clients[i].fd == 0)
			continue;
		printf ( "%-5d%-35s%-20s%-8d\n", 
				svr.clients[i].fd, svr.clients[i].name, 
				svr.clients[i].ip_address, svr.clients[i].port);
	}
	fflush (stdout);
}

void add_client_to_list (struct client* c) {

	/**
	 * Add the client to our clients list
	 * and send it the list of existing clients if any.
	 */
	int i;
	for (i = 0; i < MAX_PEERS; i++) {
		if (svr.clients[i].port == 0) {
			memcpy (&(svr.clients[i]), c, sizeof (struct client));
			printf ("Hostname & Port: %s:%d\n", svr.clients[i].name,
					svr.clients[i].port);
			fflush (stdout);
			svr.clients_connected++;
			break;
		}
	}
	send_peer_list ();
}

/**
 * Send the list of other clients to this new client.
 */
void send_peer_list () {
	int i;
	struct peer_list_node* pln = (struct peer_list_node*) malloc (
			sizeof (struct peer_list_node));
	pln->magic = IM_A_PEERLIST;
	pln->peers = 0;
	for (i = 0; i < MAX_PEERS; i++) {
		if (svr.clients[i].port == 0)
			bzero (&(pln->clients[i]), sizeof (struct client));
		else {
			int b = svr.clients[i].fd;
			svr.clients[i].fd = 0;
			svr.clients[i].open_file_descriptor = 0;
			memcpy (&(pln->clients[i]), &(svr.clients[i]), sizeof (struct client));
			svr.clients[i].fd = b;
			pln->peers++;
		}
	}

	for (i = 0; i < MAX_PEERS; i++) {
		if (svr.clients[i].fd != 0 && svr.clients[i].port != 0) {
			int w = writen (svr.clients[i].fd, pln, sizeof (struct peer_list_node));
		}
	}
	return;
}

void write_part_to_file (int fd, struct part* p) {
	struct client* c = get_client_from_fd (fd);
	if (c->open_file_descriptor < 1) {
		c->open_file_descriptor = open (basename (p->parent.name), O_RDWR | O_CREAT, S_IRUSR | S_IRGRP | S_IROTH);
		if (c->open_file_descriptor < 0) {
			perror ("CaNNOT OPEN FILE");
			exit (-1);
		}
		gettimeofday (&(c->file_transfer_start), NULL);
	}

	if (writen (c->open_file_descriptor, p->data, p->actual_size_of_payload) < 0) {
		fflush (stdout);
		perror ("Cannot WRITE TO FILE");
		exit (-1);
	}
	if (p->last_part_flag == 1) {
		close (c->open_file_descriptor);
		c->open_file_descriptor = 0;
		struct timeval end_time;
		gettimeofday (&end_time, NULL);
		int cc = 0;
		for (cc = 0; cc < MAX_PEERS; cc++) {
			if (!strcmp (c->name, cli.statistics.s_stats[cc].target_name)) {
				cli.statistics.s_stats[cc].bytes_transferred +=
					p->parent.size;
				long int ttt = (end_time.tv_sec - c->file_transfer_start.tv_sec) * 1000;
				if ((end_time.tv_usec - c->file_transfer_start.tv_usec) > 0) {
					ttt =	(end_time.tv_usec - c->file_transfer_start.tv_usec);
				} else {
					ttt -= 1000;
					ttt +=
						((c->file_transfer_start.tv_usec - end_time.tv_usec) / 1000.0);
				}
				cli.statistics.s_stats[cc].downloads++;
				cli.statistics.s_stats[cc].milliseconds_transferred +=ttt;
				printf ("TOTAL TIME TO TRANSFER FILE: %ld milliseconds.\n", (ttt) / 1000);
				fflush (stdout);
			}

		}

	}

}

void send_file_to_client (int fd, char* file_path) {
	struct client* c = get_client_from_fd (fd);
	gettimeofday (&(c->file_transfer_start), NULL);

	int file_descriptor = open (file_path, O_RDONLY);
	if (file_descriptor < 0) {
		perror ("FileError");
		return;
	}
	struct stat file_stats;
	if (fstat (file_descriptor, &file_stats) < 0) {		
		perror ("Stat Error");
		return;
	}

	int last_part = file_stats.st_size / FILE_PART_SIZE;
	int part_index = 0;
	struct file* f = (struct file*) malloc (sizeof (struct file));
	f->magic = IM_A_FILE;
	f->size = file_stats.st_size;
	strcpy (f->name, file_path);
	int i = 0;
	char buffer[FILE_PART_SIZE];
	while (( i = read (file_descriptor, buffer, sizeof (buffer))) > 0) {
		struct part* p = (struct part*) malloc (sizeof (struct part));
		bzero (p, sizeof (struct part));
		memcpy (p->data, buffer, i);
		memcpy (&(p->parent), f, sizeof (struct file));
		p->magic = IM_A_FILEPART;
		p->last_part_flag = 0;
		p->actual_size_of_payload = i;
		if (part_index == last_part - 1) {
			p->last_part_flag = 1;
		}
		if (writen (fd, p, sizeof(struct part)) < 0) {
			perror ("FILE_PART_WRITE_ERROR");
			exit (-1);
		}
		free (p);
		if (part_index == last_part - 1) {
			struct timeval end_time;
			gettimeofday (&end_time, NULL);
			int cc = 0;
			for (cc = 0; cc < MAX_PEERS; cc++) {
				if (!strcmp (c->name, cli.statistics.s_stats[cc].target_name)) {
					cli.statistics.s_stats[cc].bs +=
						p->parent.size;
					long int ttt = (end_time.tv_sec - c->file_transfer_start.tv_sec) * 1000000;
					if ((end_time.tv_usec - c->file_transfer_start.tv_usec) > 0) {
						ttt =	(end_time.tv_usec - c->file_transfer_start.tv_usec);
					} else {
						ttt -= 1000000;
						ttt +=
							(c->file_transfer_start.tv_usec - end_time.tv_usec);
					}
					cli.statistics.s_stats[cc].uploads++;
					cli.statistics.s_stats[cc].ms +=ttt;
					printf ("TOTAL TIME TO TRANSFER FILE: %ld milliseconds.\n", (ttt) / 1000);
					fflush (stdout);
				}
			}
		}
		part_index++;
	}

	perror ("SFTC");

}

/*
 * Some global variables.
 */
int jpeg;
int totalOffset;
int kk = 0;
/**
 * The main read funtion. Parts (and writen) of this 
 * funtion are taken from
 * UNIX Network Programming Volumn 1 by W. Richard Stevens.
 */
ssize_t readm (int fd, int* type, char* datai) {
	size_t nleft;
	ssize_t nread;
	char* ptr;
	/**
	 * We can interchangeably use pointer types here, because both struct 
	 * an int as their first data member.
	 * This should be optimized later to read only 4 bytes first,
	 * and then read the remaining sizeof () - 2 later.
	 */
	int n = sizeof (struct part);
	if (n < sizeof (struct client)) {
		n = sizeof (struct client);
	}

	type = (int*) malloc (sizeof (int));
	n = 35000;
	char vptr[n];
	bzero (vptr, n + 1);
	ptr = vptr;

	int total_bytes_to_be_read = 0;

	if (fd == 0) {
		nleft = MAXLINE;
	} else 
		nleft = sizeof (int);
	int packet_type_recognized = 0;
	total_bytes_to_be_read = nleft;
	while (nleft > 0) {
		if ((nread = read (fd, ptr, nleft)) < 0) {
			if (errno == EINTR)
				nread = 0;
			else{ 
				perror ("FATALERROR");
				exit (-1);
				return -1;
			}
		} else if (nread == 0)
			break;

		int magic = (int) *vptr;
		if (fd == 0) {
			break;
		} else if (magic == IM_A_CLIENT && packet_type_recognized == 0) {
			/**
			 * This is client initialiing itself by sending its
			 * information.
			 */
			nleft = sizeof (struct client);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		} else if (magic == IM_A_FILE && packet_type_recognized == 0) {
			/**
			 * This is a file packet.
			 */
			nleft = sizeof (struct part);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		} else if (magic == IM_A_MESSAGE && packet_type_recognized == 0) {
			/**
			 * This is a text message
			 */
			nleft = sizeof (struct message);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		} else if (magic == IM_A_PEERLIST && packet_type_recognized == 0) {
			nleft = sizeof (struct peer_list_node);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
			/*
				 } else if (magic == PEER_LIST_STOP && packet_type_recognized == 0) {
				 printf ("Peer List Stopped.\n");
				 total_bytes_to_be_read = 0;
				 n = nleft;
			 *type = magic;
			 */
		}else if (magic == IM_A_PEER && packet_type_recognized == 0) {
			nleft = sizeof (struct client);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		} else if (magic == IM_A_FILE_REQUEST && packet_type_recognized == 0) {
			nleft = sizeof (struct file);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		} else if (magic == IM_A_FILEPART && packet_type_recognized == 0) {
			nleft = sizeof (struct part);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		} else if (magic == IM_A_STAT_REQUEST && packet_type_recognized == 0) {
			nleft = sizeof (int);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;

		}else if (magic == IM_A_STAT_ARRAY && packet_type_recognized == 0) {
			nleft = sizeof (struct master_stats);
			total_bytes_to_be_read = nleft;
			n = nleft;
			*type = magic;
		}else if (packet_type_recognized == 0) { 
			printf ("Invalid Packet Type %d.\n", magic);
			*type = -1;
			fflush (stdout);
			return 0;
		}

		packet_type_recognized = 1;

		nleft -= nread;
		ptr += nread;
	}
	fflush (stdout);
	if (nread == 0 && nleft == total_bytes_to_be_read) { 
		/**
		 * A client closed the connection, and thus,
		 * we are returning 0. 
		 * select returns true for this client even though no data was
		 * recieved because the connection was closed.
		 */
		return 0;
	}
	strcpy (datai ,vptr);	 
	if (fd == 0) {
		return (n - nleft);
	}

	struct part* p = (struct part*) vptr;
	if (p->magic != IM_A_FILEPART)	{
		if (p->magic == IM_A_CLIENT) {
			struct client* c = NULL;
			c = (struct client*) vptr;
			if (c->magic == IM_A_CLIENT)  {
				c->fd = fd;
				add_client_to_list (c);
			} 
		} else if (p->magic == IM_A_PEERLIST) {
			if (cli.peers == NULL) {
				cli.peers = malloc (sizeof (struct peer_list_node));
				bzero (cli.peers, sizeof (struct peer_list_node));
			}
			struct peer_list_node* pln = NULL;
			pln = (struct peer_list_node*) vptr;
			int z[4];
			int y;
			for (y = 0; y < MAX_PEERS; y++)
				z[y] = cli.peers->clients[y].fd;
			cli.peers = (struct peer_list_node*) malloc (sizeof (
						struct peer_list_node));

			memcpy (cli.peers, pln, sizeof (struct peer_list_node));
			for (y = 0; y < MAX_PEERS; y++)
				if (cli.peers->clients[y].port != 0)
					cli.peers->clients[y].fd = z[y];
			print_peer_list (CLIENT_LIST);
			for (y = 0; y < MAX_PEERS; y++) {
				strcpy (cli.statistics.s_stats[y].target_name, cli.peers->clients[y].name);
			}
		} else if (p->magic == IM_A_PEER) {
			struct client* c = NULL;
			c = (struct client*) vptr;
			int ii = 0;
			printf ("Peer Connected.\n");
			for (ii = 0; ii < MAX_PEERS; ii++) {
				if (cli.peers->clients[ii].port == c->port) {
					cli.peers->clients[ii].fd = fd;
					break;
				}
			}
		} else if (p->magic == IM_A_STAT_REQUEST) {
			/*
			 * Stat request recieved.
			 * Send over our stat structure.
			 */
			send_stat_structure_to_server (fd);

		} else if (p->magic == IM_A_STAT_ARRAY) {
			struct master_stats* mstats = (struct master_stats*) vptr;
			int ii = 0;
			for (ii = 0; ii < MAX_PEERS; ii++) {
				if (!strcmp(mstats->self_name, svr.clients[ii].name)) {
					memcpy (&(svr.clients[ii].statistics),
							mstats, sizeof (struct master_stats));
				}
			}

			/*
			 * Check whether stats from all clients has been receiverd.
			 */
			int stats_not_received = 0;
			for (ii = 0; ii < MAX_PEERS; ii++) {
				if (svr.clients[ii].fd != 0) {
					if (svr.clients[ii].statistics.magic == 0) {
						stats_not_received = 1;
					}
				}
			}
			/*
			 * DISPLAY
			 */
			if (stats_not_received == 1) {
				fflush (stdout);
				return n;
			}
			display_stats_on_server ();

			for (ii = 0; ii < MAX_PEERS; ii++) {
				bzero (&(svr.clients[ii].statistics),
						sizeof (struct master_stats));
			}

		} else if (p->magic == IM_A_FILE_REQUEST) {
			struct file* f = (struct file*) vptr;
			send_file_to_client (fd, f->name);
		} else if (p->magic == IM_A_FILEPART) {
			struct part* p = (struct part*) vptr;
			write_part_to_file (fd, p);
		}
		fflush (stdout);
		return n;
	} else {
		struct part*p = (struct part*) vptr;
		write_part_to_file(fd, p);
		return n;
	}

	if ((totalOffset + FILE_PART_SIZE) > p->parent.size) {
		kk = p->parent.size - totalOffset;
	}

	if (totalOffset >= p->parent.size)
		return 0;

	//	printf ("Messag: %s\n", recvd_part);
	if ((n - nleft) != 0) {
		if (kk == 0) {
			write (jpeg, p->data, FILE_PART_SIZE);
			totalOffset += FILE_PART_SIZE;
		} else {
			write (jpeg, p->data, kk);
			printf ("Last\n");
			totalOffset += kk;	
			kk = 0;
		}
	}
	fflush (stdout);
	return (n - nleft);
}

void handle_new_connection (int listenfd, int* fdmax, fd_set* master) {
	// Handler New Connection.
	struct sockaddr_in servaddr;
	socklen_t addrlen = sizeof (servaddr);

	bzero (&servaddr, sizeof (servaddr));

	int newfd = accept (listenfd, (struct sockaddr*)
			&servaddr, &addrlen);
	if (newfd == -1){
		perror ("Accept Error");
		exit (-1);
	} else {
		FD_SET (newfd, master);
		if (newfd >= *fdmax) {
			*fdmax = newfd;
		}
	}
}


void handle_command_line (int listenfd, char* data) {
	if (*data == -1)
		return;
	if (!strcasecmp (data, "MYIP\n")) {
		if (machine_type == SERVER)
			printf ("IP address:%s", svr.ip_address);
		else
			printf ("IP address:%s", cli.ip_address);
		printf ("\n");
	} else if (!strcasecmp (data, "HELP\n")){
		printf ("List of commands that can be used.\n");
		printf ("----------------------------------------------------\n");
		printf ("CREATOR   :  My Details.\n"); // DONE
		printf ("HELP      :  Display this help.\n"); // DONE
		printf ("MYIP      :  Display the IP Address of this machine.\n"); // DONE
		printf ("MYPORT    :  Display the IP Address of this port.\n"); // DONE
		printf ("REGISTER  :  Register the client with the Server\n"); // DONE
		printf ("             Only Available for the client.\n");  // DONE
		printf ("CONNECT   :  Connect to another peer.\n"); // DONE 
		printf ("             Only Available for the client.\n"); // DONE
		printf ("LIST      :  Display all alive connections.\n"); // DONE
		printf ("TERMINATE :  Will terminate the connection with \n");
		printf ("             the specified peer.\n");
		printf ("EXIT      :  Exit the application.\n");
		printf ("UPLOAD    :  Upload a file to a peer.\n");
		printf ("DOWNLOAD  :  Download a file from another peer.\n");
		printf ("STATISTICS:  Display Statistics about the current\n");
		printf ("             connections.\n");
		printf ("---------------------------------------------------\n");
	} else if (!strcasecmp (data, "MYPORT\n")) {
		if (machine_type == SERVER)
			printf ("Port number:%d", svr.port);
		else 
			printf ("Port number:%d", cli.port);
		printf ("\n");
	} else if (!strcasecmp (data, "CREATOR\n")) {
		printf ("Name      : Aniket Mahesh Deole\n");
		printf ("UBIT Name : aniketma\n");
		printf ("UB Email  : aniketma@buffalo.edu\n");
		printf ("I have read and understood the academic integrity policy located at http://www.cse.buffalo.edu/faculty/dimitrio/courses/cse4589_f14/index.html#integrity");
		printf ("\n");
	} else if (!strcasecmp (data, "EXIT\n")) {
		printf ("Terminating Application.\n");
		exit_process ();	
	} else if (!strncasecmp (data, "REGISTER ", strlen ("REGISTER "))) {
		if (machine_type == CLIENT) {
			int port;
			char command[strlen ("REGISTER")];
			char ip[15];
			sscanf (data, "%s %s %d", command, ip, &port);
			/*
			 * Check for self connections.
			 */
			if (!strcmp (ip, cli.ip_address) &&
					port == cli.port) {
				printf ("Cannot Self Connect.\n");
			} else

				/**
				 * We register with the server
				 * an send all our client metadata.
				//			sscanf (data, "%s %d.%d.%d.%d %d", command, &ip1,
				 */
				if (!connect_to_server (listenfd, ip, port)) { 
					bzero (&(cli.statistics), sizeof (struct master_stats));
					strcpy (cli.statistics.self_name, cli.name);

				} else {
					printf ("Cannot connect to server.\n");
				}
			fflush (stdout);
		} else {
			printf ("Invalid Command.\n");
		}
	} else if (!strcasecmp (data, "LIST\n")){
		if (machine_type == SERVER)
			print_client_list ();
		else{
			fflush (stdout);
			print_peer_list (PEER_LIST);
			fflush (stdout);
		}
	} else if (!strncasecmp (data, "CONNECT ", strlen ("CONNECT "))) {
		/**
		 * Connect to another client to either upload or download a file.
		 */
		if (machine_type == SERVER) {
			printf ("Invalid Command.\n");
			return;
		}
		connect_to_peer (data);
	} else if (!strncasecmp (data, "DOWNLOAD ", strlen ("DOWNLOAD "))) {
		download_files (data);
	} else if (!strncasecmp (data, "UPLOAD ", strlen ("UPLOAD "))) {
		int index;
		char command[strlen("UPLOAD")];
		char filePath[1024];
		sscanf (data, "%s %d %s", command, &index,filePath);
		send_file_to_client (index, filePath);
	} else if (!strncasecmp (data, "TERMINATE ", strlen ("TERMINATE "))) {
		terminate_connection (data);
	} else if (!strncasecmp (data, "STATISTICS\n", strlen ("STATISTICS\n"))) {
		print_statistics ();
	} else {
		printf ("Invalid Command\n");
	}
	fflush (stdout);
	return;
}

int select_loop (int listenfd, int readable_fds) {
	int i;
	for (i = 0; i <= fdmax; i++) {
		if (FD_ISSET (i, &read_fds)) {
			readable_fds--;
			if (i == listenfd) {
				handle_new_connection (listenfd, &fdmax, &master);
				read_fds = master;
			} else {
				/**
				 * Read data from Client.
				 */
				fflush (stdout);
				int *type;
				char* data = (char*) malloc (MAXLINE + 1);
				bzero (data, MAXLINE + 1);
				int l;
				l = readm (i, type, data);
				if (i == STDIN)
					handle_command_line (listenfd, data);
				else {
					if (l <= 0) {
						if (l < 0) {
							perror ("Read Error");
						}
						if (close (i) < 0) {
							perror ("Close Error");
						}
						int kk = 0;
						if (machine_type == CLIENT) {
							if (i == svr.fd) {
								exit_process ();
							}
						}
						for (kk = 0; kk < MAX_PEERS; kk++) { 
							if (machine_type == CLIENT) {
								if (cli.peers->clients[kk].fd == i) {
									cli.peers->clients[kk].fd = 0;
								}
							} else if (machine_type == SERVER) {
								if (svr.clients[kk].fd == i) {
									svr.clients[kk].fd = 0;
									svr.clients[kk].port = 0;
									/*
									 * SEND UPDATE LIST TO EVERY CLIENT.
									 */
									send_peer_list ();
								}
							}
							FD_CLR (i, &master);
							close (i);
						}
					} // if (l <= 0)
				} // else if i == STDIN
			} // else if i == listenfd
		} // if FD_ISSET i readfds
		if (readable_fds <= 0)
			break;
	} // for
	return fdmax;
}

void get_machine_details () {

	struct sockaddr_in servaddr;
	bzero (&servaddr, sizeof (struct sockaddr_in));

	int sockfd, n;
	sockfd = socket (AF_INET, SOCK_DGRAM, 0);

	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons (GOOGLE_DNS_PORT);
	inet_pton (AF_INET, GOOGLE_DNS, &servaddr.sin_addr);
	if (connect (sockfd,  (struct sockaddr*) &servaddr,
				sizeof (servaddr)) < 0) {
		perror ("Error getting machine ip details");
		return;
	}
	socklen_t len = sizeof (struct sockaddr);	
	struct sockaddr_in* self_servaddr = malloc (sizeof (
				struct sockaddr_in));
	if (getsockname (sockfd, (struct sockaddr*) self_servaddr,
				&len) < 0) {
		perror ("Error getting machine ip details");
		return;
	}

	if (machine_type == SERVER) {
		svr.address = *self_servaddr;
		strcpy (svr.ip_address, inet_ntoa (svr.address.sin_addr));
		if (getnameinfo ((struct sockaddr*) self_servaddr, sizeof (struct sockaddr),
					svr.name, sizeof (svr.name), svr.service, sizeof (svr.service), 0) < 0) {
			perror ("Error getting machine ip details");
			return;
		}
	} else if (machine_type == CLIENT){
		cli.address = *self_servaddr;
		strcpy (cli.ip_address, inet_ntoa (cli.address.sin_addr));
		if (getnameinfo ((struct sockaddr*) self_servaddr, sizeof (struct sockaddr),
					cli.name, sizeof (cli.name), cli.service, sizeof (cli.service), 0) < 0) {
			perror ("Error getting machine ip details");
			return;
		}
	}
	close (sockfd);

	return;
}

