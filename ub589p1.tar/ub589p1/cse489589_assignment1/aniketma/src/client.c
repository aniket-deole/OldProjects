#include "../include/global.h"
#include "../include/defs.h"

#include <sys/stat.h>

extern fd_set master;
extern fd_set read_fds;

ssize_t writen (int fd, const void* vptr, size_t n) {
	size_t nleft;
	ssize_t nwritten;
	const char* ptr;

	ptr = vptr;
	nleft = n;
	while (nleft > 0) {
		if ((nwritten = write (fd, ptr, nleft)) <= 0) {
			if (nwritten < 0 && errno == EINTR)
				nwritten = 0;
			else
				return -1;
		}

		nleft -= nwritten;
		ptr+= nwritten;
	}
	return (n - nleft);
}

int connect_to_server (int listenfd, char* ip, int port) {
	struct sockaddr_in servaddr;
	bzero (&servaddr, sizeof (struct sockaddr_in));
	
	int sockfd, n;
	sockfd = socket (AF_INET, SOCK_STREAM, 0);

	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons (port);
	
	inet_pton (AF_INET, ip, &servaddr.sin_addr);
	svr.port = port;
	strcpy (svr.ip_address, ip);
	if (connect (sockfd, (struct sockaddr*) &servaddr, 
				sizeof (servaddr)) < 0) {
		perror ("");
		return -1;
	}
	FD_SET (sockfd, &master);
	FD_SET (sockfd, &read_fds);
	
	int a = getnameinfo ((struct sockaddr*) &servaddr,
		sizeof (servaddr), svr.name, sizeof (svr.name),
		svr.service, sizeof (svr.service), 0);

	if (sockfd >= fdmax)
		fdmax = sockfd;

	svr.fd = sockfd;

	cli.magic = IM_A_CLIENT;
	int w = writen (sockfd, &cli, sizeof (struct client));
	if (w <= 0) {
		perror ("");
	}
	return 0;
}

int run_client (int port_number) {
	/**
	 * Set the machine Type so that the other functions can act 
	 * accordingly.
	 */
	machine_type = CLIENT;
	svr.fd = 0;
	/**
	 * Identify the current machine and fill up the cli data structure.
	 */
	cli.port = port_number;
	get_machine_details ();
	
	
	listenfd = socket (AF_INET, SOCK_STREAM, 0);
	if (listenfd < 0) {
		printf ("Socket Error.\n");
		exit (-1);
	}

	struct sockaddr_in servaddr;
	bzero (&svr, sizeof (struct server));	
	bzero (&servaddr, sizeof (servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl (INADDR_ANY);
	servaddr.sin_port = htons(cli.port);

	if (bind (listenfd, (struct sockaddr*) &servaddr,
		sizeof (servaddr)) < 0) {
		perror ("Bind Error");
		exit (-1);
	}

	if (listen (listenfd, LISTEN_BACKLOG) < 0) {
		perror ("Listen Error");
		exit (-1);
	}

	fflush (stdout);
	/**
	 * Initialize datastructres for the select sys call.
	 */
	fdmax = listenfd;
	FD_ZERO (&master);
	FD_ZERO (&read_fds);
	FD_SET (listenfd, &master);
	FD_SET (0, &master);
	int i;
	for (;;) { 
		read_fds = master;
		int readable_fds = select (fdmax + 1, &read_fds, NULL, NULL, NULL);
		if (readable_fds == -1) {
			perror ("SELECT ERROR");
			exit (-1);
		}
		fdmax = select_loop (listenfd, readable_fds);
	}

	if (connect (listenfd, (struct sockaddr*) &servaddr, sizeof (servaddr)) < 0) {
		printf ("Connect Error.\n");
		exit (-1);
	}
	/**
	 * On a successful commit, we send our client structure, so that
	 * the server has all the required information 
	 * about us.
	 */
	cli.magic = IM_A_CLIENT;
	writen (listenfd, &cli, sizeof (struct client));
	
	sleep (10);

	close (listenfd);
	
	exit (0);	

	size_t n;
	char* line;
/*	while (getline (&line, &n, stdin) > 0) {
		n = writen (sockfd, line, n);
		printf ("%zu bytes written.\n", n);
	}
*/

	int file_descriptor = open ("dump.jpg",O_RDONLY);
	char* data = (char*) malloc (FILE_PART_SIZE);
	bzero (data, FILE_PART_SIZE);
	int sequence_number = 0;
	
	struct file* f = (struct file*) malloc (sizeof (struct file));
	strcpy (f->name, "dumpa.jpg");
	
	struct stat st;
	stat ("dump.jpg", &st);
	size_t size = st.st_size;
	f->size = size;
	while ((n = read (file_descriptor, data, FILE_PART_SIZE)) > 0) {
		struct part* p = (struct part*) malloc (sizeof (struct part));
		p->parent = *f;
		char* revData = (char*) malloc (FILE_PART_SIZE);
		int ik;
		memcpy ((p->data), data, FILE_PART_SIZE);
		int size_written = writen (listenfd, p, sizeof (struct part));
		bzero (data, FILE_PART_SIZE);
		sequence_number++;
		free (p);
	printf ("%d parts sent.\n", sequence_number);
	}

	return 0;
}	

