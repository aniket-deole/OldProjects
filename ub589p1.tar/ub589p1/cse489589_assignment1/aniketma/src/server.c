#include "global.h"
#include "defs.h"

#include <stdio.h>
#include <stdlib.h>

extern fd_set master;
extern fd_set read_fds;
void print_server_details () {
	printf ("Server hostname  : %s\n", svr.name);
	printf ("Server IP Address: %s\n", svr.ip_address);
	printf ("Server Port      : %d\n", svr.port);
}

void run_server (int port_number) {
	/**
	 * Set the machine type so that the other functions can 
	 * act accordingly.
	 */
	machine_type = SERVER;
	
	/**
	 * Identify the current machine and fill up the svr ds.
	 */
	svr.port = port_number;	
	svr.clients_connected = 0;
	get_machine_details ();
	int i;
	for (i = 0; i < MAX_PEERS; i++) 
		bzero (&(svr.clients[i]), sizeof (struct client));
	listenfd = socket (AF_INET, SOCK_STREAM, 0);
	if (listenfd < 0) {
		printf ("Socket Error.\n");
		exit (-1);
	}

	struct sockaddr_in servaddr;

	bzero (&servaddr, sizeof (servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl (INADDR_ANY);
	servaddr.sin_port = htons (svr.port);
	
	if (bind (listenfd, (struct sockaddr*) &servaddr, 
		sizeof (servaddr)) < 0) {
		printf ("Bind Error.\n");
		exit (-1);
	}

	if (listen (listenfd, LISTEN_BACKLOG) < 0) {
		printf ("Listen Error.\n");
		exit (-1);
	}

	/**
	 * Initialize datastructures for the select syscall
	 */
	
	fdmax = listenfd;
	FD_ZERO (&master);
	FD_ZERO (&read_fds);
	FD_SET (0, &master);
	FD_SET (listenfd, &master);
	for (;;) {
		read_fds = master;
		int readable_fds = select (fdmax + 1, &read_fds, NULL, NULL, NULL);
		fflush (stdout);
		if (readable_fds == -1) {
			printf ("Select Error.\n");
			exit (-1);
		}
		fdmax = select_loop (listenfd, readable_fds);
	}

	return;
}


