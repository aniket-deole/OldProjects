/**
 * @aniketma_assignment1
 * @author  Aniket Mahesh Deole <aniketma@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <stdio.h>
#include <stdlib.h>

#include "../include/global.h"
#include "../include/defs.h"

int is_server = 0;

int arg_handler (int argc, char** argv) {
	if (argc != 3) {
		printf ("Invalid Number of Arguments.\n");
		return -1;
	}

	int port_number = atoi (argv[2]);
	
	if (!strcmp (argv[1], SERVER_IDENTIFIER_CMD)) {
		is_server = 1;
		run_server (port_number);
		printf ("Initializing Server.\n");
	} else if (!strcmp (argv[1], CLIENT_IDENTIFIER_CMD)) {
		is_server = 0;
		run_client (port_number);
		printf ("Initializing Client.\n");
	} else {
		printf ("Invalid Argument\n");
		return 1;
	}

	return 0;
}


/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Start Here*/
	if (arg_handler (argc, argv)) {
		return -1;
	}
	return 0;
}
